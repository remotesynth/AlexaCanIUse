'use strict';

var features = require('./features'),
    data = require('./data/data'),
    createResponse = require('./createResponse');
 
 console.log(features['video'])
 console.log(createResponse(data,data.data.video));